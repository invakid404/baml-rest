package execute

// De-BAML Slice 6b adapter: the BAML-free PreparedRequest -> exact transport ->
// TranslateResponse -> native structured-output (SAP) pipeline for ONE unary
// OpenAI attempt.
//
// This is the ONLY thing in the de-BAML stack that knows about nanollm aliases
// AND about baml-rest's exact transport at the same time: it wires a fresh,
// Phase-5-admitted nanollm.PreparedRequest through the merged Slice-6a exact
// transport primitive (bamlutils/llmhttp ExactExecutor — ordered headers, raw
// bytes, one RoundTrip) and then back through nanollm.TranslateResponse and the
// native final parser. The Slice-6a primitive stays entirely nanollm-agnostic;
// this adapter is where the two meet.
//
// Deliberate non-goals, matching the Phase 6 scope's Option B:
//
//   - NO nanollm Do/DoStream. Exactly ONE transport attempt per RunAttempt call,
//     performed by the exact executor. There is no fallback advance, no
//     same-model retry, and no expiry re-prepare hidden in the transport — the
//     one owner of request-attempt policy is baml-rest.
//   - The exact attempted alias (prep.Meta.ModelAlias) — never a primary alias —
//     is what TranslateResponse is called with.
//   - Non-2xx and invalid-2xx are PROVIDER OUTCOMES returned as typed data, never
//     fed to the structured-output parser (SAP). A 2xx that the parser merely
//     DECLINES (ErrDeBAMLParseUnsupported) is a parity-decline recorded as data;
//     any OTHER (claimed) parse error propagates unchanged so a fallback can
//     never masquerade as a native success.
//   - This changes NO serving behavior. As of de-BAML cutover Slice 2 this
//     bridge is UNTAGGED production code (it links into the BAML+nanollm worker
//     built from this out-of-go.work module), but it is still UNREACHABLE from
//     production routing: the worker stores a native capability yet the
//     orchestrator's native child-attempt callback stays nil/hard-off. The
//     expensive Phase-5/6 oracle + go-mocklm suites that exercise it remain
//     `nanollm_integration`-gated. A later slice wires it behind the callback.

import (
	"context"
	stdjson "encoding/json"
	"errors"
	"fmt"

	"github.com/invakid404/baml-rest/bamlutils"
	"github.com/invakid404/baml-rest/bamlutils/buildrequest"
	"github.com/invakid404/baml-rest/bamlutils/llmhttp"
	nanollm "github.com/viktordanov/nanollm-ffi/go"
)

// ErrPlanExpired is returned when a prepared plan's signature window has passed
// BEFORE any socket is opened. Re-preparing belongs to the outer planner, never
// to this transport adapter, so an expired plan is rejected rather than silently
// re-signed. (OpenAI plans are unsigned and never expire; this guards the seam
// for the signed-plan providers a later phase adds.)
var ErrPlanExpired = errors.New("nativeserve: prepared plan expired before attempt")

// ErrAttemptUnsupported is the umbrella sentinel for a parity-decline: the
// native support decision refused a plan BEFORE opening a socket, so native
// never out-claims BAML on a shape it has not proven. Recover the stable
// stage/reason via errors.As(&UnsupportedError{}).
var ErrAttemptUnsupported = errors.New("nativeserve: prepared plan not supported by the native unary attempt")

// UnsupportedError carries a stable, secret-free stage/reason for a
// parity-decline (the "deferral record" the scope asks every decline to leave).
// It unwraps to ErrAttemptUnsupported.
type UnsupportedError struct {
	Stage  string
	Reason string
}

func (e *UnsupportedError) Error() string {
	return fmt.Sprintf("nativeserve: unsupported attempt (%s): %s", e.Stage, e.Reason)
}

func (e *UnsupportedError) Unwrap() error { return ErrAttemptUnsupported }

// Outcome classifies the terminal disposition of one native unary attempt.
type Outcome int

const (
	// OutcomeStructured: a provider 2xx translated to OpenAI JSON, whose
	// assistant text the native parser cleanly CLAIMED — the structured output
	// is in AttemptResult.Structured.
	OutcomeStructured Outcome = iota
	// OutcomeParseDeclined: a provider 2xx whose assistant text the native
	// parser DECLINED (ErrDeBAMLParseUnsupported). In a later production-routing
	// phase this rejoins the BAML parse fallback; here it is recorded as a
	// parity-decline (SAP WAS invoked; it simply declined).
	OutcomeParseDeclined
	// OutcomeProviderError: an ordinary provider non-2xx, translated to the
	// uniform JSON error envelope. SAP is NEVER invoked. Translated carries the
	// envelope (real status, BodyIsJSON true).
	OutcomeProviderError
	// OutcomeInvalidBody: a provider 2xx whose body TranslateResponse could not
	// parse (*nanollm.InvalidBodyError), mapped to the same 502/uniform-envelope
	// provider outcome nanollm's own Do returns. SAP is NEVER invoked.
	OutcomeInvalidBody
)

func (o Outcome) String() string {
	switch o {
	case OutcomeStructured:
		return "structured"
	case OutcomeParseDeclined:
		return "parse-declined"
	case OutcomeProviderError:
		return "provider-error"
	case OutcomeInvalidBody:
		return "invalid-body"
	default:
		return fmt.Sprintf("Outcome(%d)", int(o))
	}
}

// AttemptResult is the typed internal result of one native unary attempt. It
// preserves enough data for the later production-routing mapping (status, raw
// provider body, translated response, usage) without finalizing any public
// serving error envelope — no serving route changes in this phase.
type AttemptResult struct {
	Outcome Outcome

	// AttemptedAlias is prep.Meta.ModelAlias — the exact alias whose Prepare
	// produced the executed plan and which TranslateResponse was called with.
	AttemptedAlias string

	// ProviderStatus / ProviderBody are the RAW exact-transport observation for
	// every status: the real upstream status and the bounded raw body (16 MiB
	// success cap / 64 KiB non-2xx cap, both enforced by the exact executor).
	ProviderStatus int
	ProviderBody   []byte

	// Translated is nanollm's translated response: OpenAI JSON on 2xx, the
	// uniform error envelope on a translated non-2xx, or the synthesized
	// 502/envelope Response for an invalid-2xx. Nil only never happens on a
	// returned (nil-error) result.
	Translated *nanollm.Response

	// Usage is retained from Translated even though Phase 6 surfaces no new
	// public metadata (scope: do not discard it in an API that will need
	// redesign immediately afterward).
	Usage *nanollm.Usage

	// AssistantText is the OpenAI assistant text extracted from a 2xx body and
	// fed to SAP (empty for provider outcomes, where extraction never runs). It
	// is the text-only parseable channel — the same value the BAML final parser
	// consumes — never reasoning.
	AssistantText string

	// Raw / Reasoning are the /call-with-raw extractor channels split from the
	// SAME 2xx translated body AssistantText comes from: Raw is the text-only
	// assistant channel exposed on /call-with-raw's Raw(); Reasoning carries the
	// provider reasoning/thinking text when the caller opted in (cfg.IncludeReasoning).
	// Both are empty on provider outcomes (non-2xx / invalid-2xx), where extraction
	// never runs. They are retained so the same-response oracle can compare the
	// FULL native-vs-BAML /call-with-raw envelope (structured + raw + reasoning),
	// not just structured output (extends the Phase 6c differential).
	Raw       string
	Reasoning string

	// Structured is the flattened native structured output on OutcomeStructured
	// (nil otherwise) — the same flattened shape the generated wrapper consumes.
	Structured stdjson.RawMessage

	// DeclineReason is the parser's decline explanation on OutcomeParseDeclined.
	DeclineReason string

	// SAPInvoked records whether the native parser was called at all. It is the
	// affirmative proof that provider outcomes (non-2xx / invalid-2xx) never
	// reach SAP: those results carry SAPInvoked == false.
	SAPInvoked bool
}

// ParseResponseFunc is the SCHEMA-NEUTRAL native structured-output parser the
// response pipeline consumes (de-BAML Slice 8C): given the assistant text
// extracted from a 2xx response, it returns the flattened canonical JSON on a
// CLEAN claim, [bamlutils.ErrDeBAMLParseUnsupported] on a parity-decline (the
// caller records OutcomeParseDeclined), or any other error for a CLAIMED native
// parse failure (propagated so the differential catches drift).
//
// It is the seam that makes the response side schema-agnostic: a DYNAMIC caller
// builds it by capturing a *bamlutils.DynamicOutputSchema (see [DynamicParse]); a
// STATIC caller builds it by capturing the validated *schema.Bundle from a generated
// method's descriptor Return (debaml.ParseStaticBundle) — so this package never
// needs to know which schema flavour produced the bytes.
type ParseResponseFunc func(ctx context.Context, raw string) ([]byte, error)

// AttemptConfig is the input to RunAttempt: the nanollm client (for
// TranslateResponse with the attempted alias), the fresh Phase-5-admitted plan,
// the exact transport executor (built by the caller over a loopback-guarded
// RoundTripper — the adapter stays transport-agnostic), and the schema-neutral
// response parser closure.
type AttemptConfig struct {
	Client   *nanollm.Client
	Prepared *nanollm.PreparedRequest
	Executor *llmhttp.ExactExecutor

	// ParseResponse is the schema-neutral parser (de-BAML Slice 8C). It is the
	// PREFERRED input: when non-nil the pipeline drives it directly and needs no
	// OutputSchema. A static serve caller sets it to a closure capturing the
	// descriptor Return Bundle; the production dynamic serve caller sets it to a
	// closure capturing the DynamicOutputSchema.
	ParseResponse ParseResponseFunc

	// Parse + OutputSchema are the DYNAMIC compatibility inputs, retained so the
	// existing gated dynamic oracles keep constructing the config unchanged: when
	// ParseResponse is nil they are normalized into a ParseResponseFunc via
	// [DynamicParse]. Exactly one of {ParseResponse} or {Parse+OutputSchema} must
	// be supplied.
	Parse            bamlutils.DeBAMLParseFunc
	OutputSchema     *bamlutils.DynamicOutputSchema
	IncludeReasoning bool

	// SendHeartbeat, when non-nil, is the first-2xx liveness signal forwarded to
	// the exact executor (ExecuteWithHeartbeat): it fires the instant the provider
	// returns 2xx headers, before the body is buffered, so a pool hung-detector
	// sees liveness on a slow body. It is a pre-canary compatibility hook — the
	// native transport twin of the onSuccess callback the BAML send path gets — and
	// never mutates the request. Nil in the no-heartbeat callers (the gated 6b/6c
	// oracles), where it is a no-op.
	SendHeartbeat func()
}

// ConsumeConfig is the input to ConsumeResponse: the SAME-response consumer that
// runs native TranslateResponse -> assistant/raw/reasoning extraction -> native
// SAP over an ALREADY-COMPLETED (status, body) that some OTHER agent fetched —
// with NO transport, NO RoundTrip, and NO second provider request. It is the
// response side of RunAttempt factored out of the transport, so the de-BAML
// same-response shadow oracle can feed it BAML's already-fetched status+body
// while BAML remains the sole provider send.
//
// Client + Alias are the request-scoped nanollm client and the EXACT attempted
// alias TranslateResponse is called with (never a primary alias); ParseResponse is
// the schema-neutral native SAP closure; IncludeReasoning gates the reasoning
// extraction channel. Parse + OutputSchema are the dynamic compatibility inputs
// (see AttemptConfig) normalized into a ParseResponseFunc when ParseResponse is nil.
type ConsumeConfig struct {
	Client        *nanollm.Client
	Alias         string
	ParseResponse ParseResponseFunc

	Parse            bamlutils.DeBAMLParseFunc
	OutputSchema     *bamlutils.DynamicOutputSchema
	IncludeReasoning bool
}

// DynamicParse adapts the dynamic native parser + a carried DynamicOutputSchema
// into a schema-neutral ParseResponseFunc. It is the compatibility bridge for the
// existing dynamic serve/shadow callers and gated oracles: the response pipeline
// only ever sees the neutral closure, so it stays schema-agnostic. A nil parse or
// schema yields a closure that reports a config error on first use, matching the
// pre-refactor nil guards.
func DynamicParse(parse bamlutils.DeBAMLParseFunc, schema *bamlutils.DynamicOutputSchema) ParseResponseFunc {
	return func(ctx context.Context, raw string) ([]byte, error) {
		if parse == nil {
			return nil, fmt.Errorf("nativeserve: nil parse function")
		}
		if schema == nil {
			return nil, fmt.Errorf("nativeserve: nil output schema")
		}
		out, err := parse(ctx, bamlutils.DeBAMLParseRequest{Raw: raw, OutputSchema: schema, Stream: false})
		if err != nil {
			return nil, err
		}
		return out.JSON, nil
	}
}

// resolveParse resolves the schema-neutral parser: the explicit ParseResponse when
// present, else the DYNAMIC compatibility inputs (Parse + OutputSchema) normalized
// via DynamicParse. It returns a config error only when neither is supplied, so the
// pre-refactor "nil parse / nil schema" guards are preserved for both RunAttempt
// and ConsumeResponse.
func resolveParse(pr ParseResponseFunc, parse bamlutils.DeBAMLParseFunc, schema *bamlutils.DynamicOutputSchema) (ParseResponseFunc, error) {
	if pr != nil {
		return pr, nil
	}
	if parse == nil {
		return nil, fmt.Errorf("nativeserve: nil parse function")
	}
	if schema == nil {
		return nil, fmt.Errorf("nativeserve: nil output schema")
	}
	return DynamicParse(parse, schema), nil
}

// RunAttempt performs exactly one native unary attempt and returns the typed
// outcome.
//
// Error vs. data contract:
//
//   - Expired plan, parity-decline, and any invalid config are rejected BEFORE
//     the socket (Go error; no request is sent).
//   - Transport failures (construction, cancellation/timeout, transport, read),
//     a translate error OTHER than *InvalidBodyError, an assistant-extraction
//     failure, and a CLAIMED native parse error all propagate as Go errors.
//   - An ordinary non-2xx (OutcomeProviderError), an invalid-2xx
//     (OutcomeInvalidBody), a clean structured claim (OutcomeStructured), and a
//     parser decline (OutcomeParseDeclined) are returned as (*AttemptResult,
//     nil) — provider/parse OUTCOMES, not errors.
func RunAttempt(ctx context.Context, cfg AttemptConfig) (*AttemptResult, error) {
	if cfg.Client == nil {
		return nil, fmt.Errorf("nativeserve: nil nanollm client")
	}
	if cfg.Prepared == nil {
		return nil, fmt.Errorf("nativeserve: nil prepared request")
	}
	if cfg.Executor == nil {
		return nil, fmt.Errorf("nativeserve: nil exact executor")
	}
	// Resolve the schema-neutral parser up front (ParseResponse, else the dynamic
	// compat inputs) so a missing/incomplete parse config is rejected BEFORE the
	// socket, exactly as the pre-refactor nil guards were.
	parseResp, perr := resolveParse(cfg.ParseResponse, cfg.Parse, cfg.OutputSchema)
	if perr != nil {
		return nil, perr
	}

	prep := cfg.Prepared

	// (1) Reject an expired plan BEFORE the attempt — no re-prepare in the
	// transport. Checked first, before the support decision, so an expired plan
	// never even reaches support classification.
	if prep.Expired() {
		return nil, ErrPlanExpired
	}

	// (2) Native support decision — the parity-decline gate — runs BEFORE any
	// socket is opened. The Phase 6 admitted surface is exactly a unary,
	// non-streaming OpenAI ChatCompletion with a JSON response format and a
	// present, non-empty body; anything else declines rather than out-claiming
	// BAML on an unproven shape.
	if err := supportDecision(prep); err != nil {
		return nil, err
	}

	// (3) Convert the plan's exact fields into the neutral exact-attempt carrier
	// (ordered headers, raw body). The body is present and non-empty (support
	// decision guaranteed it), so BodyPresent is true.
	exactReq := &llmhttp.ExactAttemptRequest{
		Method:      prep.Method,
		URL:         prep.URL,
		Headers:     headerFields(prep.Headers),
		Body:        prep.Body,
		BodyPresent: true,
	}

	// (4) Exactly one exact-transport attempt. The executor performs a single
	// RoundTrip and returns status + raw body as data for EVERY status; a Go
	// error here is a non-response failure (transport-controlled-header decline,
	// request construction, cancellation/timeout, transport, or body-read).
	// cfg.SendHeartbeat (nil in the gated oracles) is the first-2xx liveness hook
	// the exact lane fires before buffering the body — never mutating the request.
	resp, err := cfg.Executor.ExecuteWithHeartbeat(ctx, exactReq, cfg.SendHeartbeat)
	if err != nil {
		return nil, err
	}

	// (5-7) The transport is done; the response side owns NO transport. Hand the
	// already-completed status+body to the same-response consumer with the EXACT
	// attempted alias — the identical pipeline the de-BAML shadow oracle drives
	// over BAML's already-fetched response.
	return ConsumeResponse(ctx, ConsumeConfig{
		Client:           cfg.Client,
		Alias:            prep.Meta.ModelAlias,
		ParseResponse:    parseResp,
		IncludeReasoning: cfg.IncludeReasoning,
	}, resp.StatusCode, resp.Body)
}

// OrdinaryAttemptConfig is the input to RunOrdinaryAttempt: the request-scoped nanollm
// client and the fresh admitted plan (as for RunAttempt), the ORDINARY llmhttp Client the
// plan is sent through, and the response-side inputs.
type OrdinaryAttemptConfig struct {
	Client   *nanollm.Client
	Prepared *nanollm.PreparedRequest
	// HTTPClient is the ordinary llmhttp Client the BAML serving path sends this request
	// through (the request adapter's client, else llmhttp.DefaultClient).
	HTTPClient *llmhttp.Client

	ParseResponse    ParseResponseFunc
	IncludeReasoning bool
	// SendHeartbeat is the first-2xx liveness callback, handed to the client exactly as
	// the BAML send path hands it (ExecuteBorrowed's onSuccess); nil becomes a no-op.
	SendHeartbeat func()
}

// RunOrdinaryAttempt performs exactly one native unary attempt like RunAttempt, but sends
// the plan through cfg.HTTPClient with the same call the BAML serving path makes for a
// child — ExecuteBorrowed with the request's context and first-2xx callback — instead of
// the exact executor. Every transport behavior is therefore that client's own: backend
// selection (fasthttp or net/http, including its ALPN probe), response framing and its
// leniency, body caps, and every error it returns.
//
// Contract:
//
//   - an expired plan, a parity-decline, and invalid config are rejected BEFORE the send
//     (Go error; nothing is sent);
//   - any error the client returns — an *llmhttp.HTTPError for a non-2xx, a transport or
//     body-read failure, an oversized body, cancellation — is returned UNCHANGED as
//     (nil, err): it is exactly the error the BAML path surfaces for the same response,
//     and no response body exists for a caller to consume;
//   - a 2xx body is copied out of the client's (possibly pooled) buffer before release and
//     consumed by ConsumeResponse, exactly as RunAttempt consumes the exact executor's.
func RunOrdinaryAttempt(ctx context.Context, cfg OrdinaryAttemptConfig) (*AttemptResult, error) {
	if cfg.Client == nil {
		return nil, fmt.Errorf("nativeserve: nil nanollm client")
	}
	if cfg.Prepared == nil {
		return nil, fmt.Errorf("nativeserve: nil prepared request")
	}
	if cfg.HTTPClient == nil {
		return nil, fmt.Errorf("nativeserve: nil ordinary HTTP client")
	}
	parseResp, perr := resolveParse(cfg.ParseResponse, nil, nil)
	if perr != nil {
		return nil, perr
	}
	prep := cfg.Prepared
	if prep.Expired() {
		return nil, ErrPlanExpired
	}
	if err := supportDecision(prep); err != nil {
		return nil, err
	}

	// The BAML path ALWAYS hands the client a first-2xx callback (RunCallOrchestration's
	// sendHeartbeat), and the callback is part of how the client picks its read path: with
	// none, a deadline-only context takes fasthttp's buffered lane, which frames a response
	// differently from the streamed-header lane the BAML path uses. A nil heartbeat is
	// therefore a no-op, never absent, so this call has the BAML path's shape.
	onSuccess := cfg.SendHeartbeat
	if onSuccess == nil {
		onSuccess = func() {}
	}
	resp, err := cfg.HTTPClient.ExecuteBorrowed(ctx, &llmhttp.Request{
		Method:  prep.Method,
		URL:     prep.URL,
		Headers: headerMap(prep.Headers),
		Body:    string(prep.Body),
	}, onSuccess)
	if err != nil {
		return nil, err
	}
	status := resp.StatusCode
	// []byte(string) copies, so the body is owned before the client's buffer is released.
	body := []byte(resp.BodyString())
	resp.Release()

	return ConsumeResponse(ctx, ConsumeConfig{
		Client:           cfg.Client,
		Alias:            prep.Meta.ModelAlias,
		ParseResponse:    parseResp,
		IncludeReasoning: cfg.IncludeReasoning,
	}, status, body)
}

// headerMap folds the plan's ordered header pairs into the ordinary Client's header map.
// The live plan compare rejects a plan with a repeated header name (its snapshot refuses
// duplicates), so an admitted plan loses nothing here.
func headerMap(pairs [][2]string) map[string]string {
	out := make(map[string]string, len(pairs))
	for _, p := range pairs {
		out[p[0]] = p[1]
	}
	return out
}

// ConsumeResponse runs the SAME-response native pipeline —
// TranslateResponse(attempted alias) -> assistant/raw/reasoning extraction ->
// native SAP — over an ALREADY-COMPLETED (status, body) that some OTHER agent
// fetched. It owns NO transport: it opens no socket, issues no RoundTrip, and
// makes no second provider request. RunAttempt calls it after its own single
// exact send; the de-BAML same-response shadow oracle calls it with BAML's
// already-fetched status+body so BAML stays the sole provider send.
//
// The error-vs-data contract is identical to RunAttempt's response side:
//
//   - An invalid-2xx (nanollm *InvalidBodyError) maps to OutcomeInvalidBody with
//     the synthesized 502/uniform-envelope Response — SAP is NEVER invoked.
//   - An ordinary non-2xx maps to OutcomeProviderError (uniform envelope) — SAP is
//     NEVER invoked.
//   - A clean 2xx whose assistant text SAP CLAIMS is OutcomeStructured; a 2xx SAP
//     DECLINES (ErrDeBAMLParseUnsupported) is OutcomeParseDeclined — both returned
//     as (*AttemptResult, nil).
//   - A translate error other than *InvalidBodyError, a non-JSON 2xx, an
//     assistant-extraction failure, and a CLAIMED (non-decline) SAP error all
//     propagate as Go errors.
//
// POST-RESPONSE ERROR CONTRACT (de-BAML cutover Slice 6): on those propagated
// errors the returned *AttemptResult is NON-NIL, carrying the response context
// fetched before the failure — ProviderStatus + ProviderBody always, plus
// Translated / AssistantText / Raw / Reasoning / SAPInvoked as far as the
// pipeline got. This lets the serving mapper distinguish a pre-claim decline
// (never reaches here) from a post-claim failure WITHOUT parsing error strings,
// retain details.raw (the raw upstream body, or the extracted assistant text on a
// CLAIMED SAP failure where SAPInvoked==true), and never fall through to a hidden
// BAML resend. A pre-response failure (nil client/parse/schema guard) still
// returns (nil, err) — there is no response context to preserve. Callers that
// only branch on `err != nil` (the shadow oracle, the 6b/6c differentials) are
// unaffected: they never dereference the result on error.
func ConsumeResponse(ctx context.Context, cfg ConsumeConfig, status int, body []byte) (*AttemptResult, error) {
	if cfg.Client == nil {
		return nil, fmt.Errorf("nativeserve: nil nanollm client")
	}
	// Resolve the schema-neutral parser (ParseResponse, else the dynamic compat
	// inputs). A missing/incomplete parse config is a pre-response guard: (nil, err)
	// with no response context to preserve, exactly as before.
	parseResp, perr := resolveParse(cfg.ParseResponse, cfg.Parse, cfg.OutputSchema)
	if perr != nil {
		return nil, perr
	}

	res := &AttemptResult{
		AttemptedAlias: cfg.Alias,
		ProviderStatus: status,
		ProviderBody:   body,
	}

	// Cancellation gate BEFORE the non-context TranslateResponse FFI: a request
	// cancelled while the socket was completing returns the typed context error
	// (with the response context on res retained), never a provider/parse outcome.
	if err := ctx.Err(); err != nil {
		return res, err
	}

	// (5) Translate with the EXACT attempted alias.
	translated, terr := cfg.Client.TranslateResponse(cfg.Alias, status, body)
	// Cancellation gate AFTER TranslateResponse (non-context FFI): a cancel that
	// raced translation wins over any translate error/outcome.
	if err := ctx.Err(); err != nil {
		return res, err
	}
	if terr != nil {
		// An invalid-2xx surfaces as the typed *InvalidBodyError carrying the
		// (caller-facing status, uniform envelope) pair. Map it into the SAME
		// response-like provider outcome Do would return — never a misclassified
		// network error, and never feed the malformed body to SAP.
		var ibe *nanollm.InvalidBodyError
		if errors.As(terr, &ibe) {
			res.Outcome = OutcomeInvalidBody
			res.Translated = &nanollm.Response{
				Status:     ibe.Status,
				Body:       ibe.Envelope,
				BodyIsJSON: true,
			}
			return res, nil
		}
		// Any other translate failure is a genuine error (not a provider
		// outcome, not SAP-eligible) and propagates — with the response context
		// (status + raw body) retained on res for the serving mapper's details.raw.
		return res, fmt.Errorf("nativeserve: TranslateResponse(%s): %w", cfg.Alias, terr)
	}

	res.Translated = translated
	res.Usage = translated.Usage

	// (6) Ordinary non-2xx: TranslateResponse normalized it into the uniform
	// JSON error envelope (real status, BodyIsJSON true). It is a provider
	// outcome; SAP is NEVER invoked.
	if translated.Status < 200 || translated.Status >= 300 {
		res.Outcome = OutcomeProviderError
		return res, nil
	}

	// (7) Unary 2xx: require a valid JSON body, extract the OpenAI assistant
	// text + raw + reasoning (translated.Body is OpenAI-format regardless of the
	// original provider), and feed the assistant text to the native parser. Raw
	// and reasoning are retained on the result so the same-response oracle can
	// compare the full /call-with-raw envelope, not just structured output.
	if !translated.BodyIsJSON {
		return res, fmt.Errorf("nativeserve: 2xx translated response is not JSON (status %d)", translated.Status)
	}
	parseable, raw, reasoning, xerr := buildrequest.ExtractResponseContentBytes("openai", translated.Body, cfg.IncludeReasoning)
	if xerr != nil {
		return res, fmt.Errorf("nativeserve: extracting assistant text: %w", xerr)
	}
	res.AssistantText = parseable
	res.Raw = raw
	res.Reasoning = reasoning

	// Cancellation gate BEFORE the native SAP FFI (the production parser discards
	// ctx internally), so a cancel that raced the post-2xx pipeline returns the
	// typed context error with the response context retained, not a parse outcome.
	if err := ctx.Err(); err != nil {
		return res, err
	}

	// SAP is invoked exactly here and nowhere else on the 2xx path. The parser is
	// the schema-neutral closure: DYNAMIC callers capture a DynamicOutputSchema,
	// STATIC callers capture the descriptor Return Bundle — this pipeline is blind
	// to which.
	res.SAPInvoked = true
	parsedJSON, sperr := parseResp(ctx, parseable)
	// Cancellation gate AFTER SAP: a cancel that raced the parser wins over any
	// parse decline/error/success classification.
	if err := ctx.Err(); err != nil {
		return res, err
	}
	if sperr != nil {
		// A clean decline is a parity-decline recorded as data (no fallback
		// rejoined here — no serving change in this phase). Any OTHER parse
		// error is a CLAIMED native failure and propagates UNCHANGED so the
		// differential can catch native-vs-BAML drift.
		if errors.Is(sperr, bamlutils.ErrDeBAMLParseUnsupported) {
			res.Outcome = OutcomeParseDeclined
			res.DeclineReason = sperr.Error()
			return res, nil
		}
		// A CLAIMED (non-decline) native parse failure. res carries the response
		// context — AssistantText/Raw/Reasoning (SAPInvoked==true) — so the serving
		// mapper can attach the extracted assistant text as details.raw.
		return res, sperr
	}

	res.Outcome = OutcomeStructured
	res.Structured = parsedJSON
	return res, nil
}

// supportDecision is the parity-decline gate. It runs before any socket and
// declines with a stable, secret-free stage/reason for anything outside the
// admitted unary chat surface. The OpenAI-only provider requirement is REMOVED
// (§7): admission's mapper + verification policy already decided provider
// support, and TranslateResponse normalizes every provider's 2xx into OpenAI JSON
// (so response extraction stays "openai" downstream). What remains is the
// provider-NEUTRAL shape this transport can send once and consume: a
// non-streaming ChatCompletion with a JSON response format, POST method, and a
// present, non-empty body — anything else declines rather than out-claiming BAML
// on an unproven shape. Header VALUES and body bytes are never referenced, so a
// decline diagnostic can never leak a secret.
func supportDecision(prep *nanollm.PreparedRequest) error {
	m := prep.Meta
	if m.RequestType != nanollm.ChatCompletion {
		return &UnsupportedError{Stage: "request_type", Reason: fmt.Sprintf("request type %q is not chat_completion", m.RequestType)}
	}
	if m.Stream {
		return &UnsupportedError{Stage: "stream", Reason: "streaming is out of scope for the unary attempt (Phase 7)"}
	}
	if prep.ResponseFormat != nanollm.FormatJSON {
		return &UnsupportedError{Stage: "response_format", Reason: fmt.Sprintf("response format %q is not json", prep.ResponseFormat)}
	}
	if prep.Method != "POST" {
		return &UnsupportedError{Stage: "method", Reason: fmt.Sprintf("method %q is not POST", prep.Method)}
	}
	if len(prep.Body) == 0 {
		return &UnsupportedError{Stage: "body", Reason: "prepared body is empty"}
	}
	return nil
}

// headerFields converts nanollm's ordered [][2]string plan headers into the
// exact carrier's []HeaderField, preserving pair order and repeated names — the
// two properties the exact lane must not lose. Values are copied verbatim; the
// adapter never rewrites, adds, or drops a header.
func headerFields(pairs [][2]string) []llmhttp.HeaderField {
	out := make([]llmhttp.HeaderField, len(pairs))
	for i, p := range pairs {
		out[i] = llmhttp.HeaderField{Name: p[0], Value: p[1]}
	}
	return out
}
